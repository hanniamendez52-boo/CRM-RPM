const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");
admin.initializeApp();

/**
 * Función programada a las 8:30 p.m. (20:30) en zona horaria America/Mexico_City.
 * Envía el resumen de registros del día a todos los dispositivos registrados en FCM.
 * Regla: Si no hay registros ese día, NO se envía nada.
 */
exports.dailyRegistrationSummary = onSchedule({
  schedule: "30 20 * * *",
  timeZone: "America/Mexico_City"
}, async (event) => {
  const db = admin.firestore();
  const now = new Date();
  const todayStr = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Mexico_City' }).format(now);

  console.log(`[Resumen Diario 8:30 PM] Verificando registros para fecha: ${todayStr}`);

  // Consultar clientes creados en la fecha de hoy
  const clientsSnap = await db.collection("clients").get();
  const todayClients = [];
  clientsSnap.forEach(doc => {
    const data = doc.data();
    const created = data.createdAt ? String(data.createdAt).slice(0, 10) : "";
    if (created === todayStr) {
      todayClients.push(data);
    }
  });

  const count = todayClients.length;
  console.log(`[Resumen Diario 8:30 PM] Total registrados hoy: ${count}`);

  // Si en ese día no hay registros, NO enviar nada
  if (count === 0) {
    console.log("[Resumen Diario 8:30 PM] Sin registros el día de hoy. No se envía notificación.");
    return null;
  }

  // Preparar contenido de la notificación
  const names = todayClients.slice(0, 3).map(c => c.company || c.contactName).filter(Boolean).join(", ");
  const extra = count > 3 ? ` y ${count - 3} más` : "";
  const bodyText = `Hoy se registraron ${count} persona(s)/cliente(s): ${names}${extra}.`;

  // Obtener tokens FCM de dispositivos suscritos
  const tokensSnap = await db.collection("fcm_tokens").get();
  const tokens = [];
  tokensSnap.forEach(doc => {
    const token = doc.data().token;
    if (token) tokens.push(token);
  });

  if (tokens.length === 0) {
    console.log("[Resumen Diario 8:30 PM] No hay dispositivos registrados en fcm_tokens.");
    return null;
  }

  const message = {
    notification: {
      title: "Campo360 · Resumen del día (8:30 p.m.)",
      body: bodyText
    },
    data: {
      type: "daily_summary",
      date: todayStr,
      count: String(count)
    },
    tokens: tokens
  };

  const response = await admin.messaging().sendEachForMulticast(message);
  console.log(`[Resumen Diario 8:30 PM] Notificaciones enviadas: ${response.successCount} exitosas, ${response.failureCount} fallidas.`);
  return null;
});
